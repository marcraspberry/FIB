typedef struct {
	char c;
	int k;
	int *m;
}S1;

