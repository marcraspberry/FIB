#include "elemento.h"

void Asignar(S1 v[], S1 X, int pos) {

  v[pos].c = X.c;
  v[pos].k = X.k;
  v[pos].m = X.m;

}

